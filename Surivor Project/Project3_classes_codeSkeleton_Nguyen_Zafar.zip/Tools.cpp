#include "Tools.h"
#include <iostream>
using namespace std;

    Tools::Tools()
    {
        powerLevel = 0;
        type = "";
    }
    Tools::Tools(int pL, string t)
    {
        powerLevel = pL;
        type = t;
    }
    void Tools::setPowerLevel(int pL)
    {
        powerLevel = pL;
    }
    int Tools::getPowerLevel()
    {
        return powerLevel;
    }
    void Tools::setType(string t)
    {
        type = t;
    }
    string Tools::getType()
    {
        return type;
    }