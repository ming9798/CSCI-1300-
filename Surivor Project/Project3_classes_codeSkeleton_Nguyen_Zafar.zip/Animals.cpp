//CS1300
//Authors: Mia Nguyen and Tahira Zafar

#include "Animals.h"
#include <iostream>
using namespace std;

    Animals::Animals()
    {
        color="";
        name = "";
        weight=0.0;
        dangerScore=0;
    }
    Animals::Animals(string nameStr, string c, double s, int dS)
    {
        color = c;
        weight = s;
        dangerScore = dS;
        name = nameStr;

    }
    void Animals::setColor(string c)
    {
        color = c;
    }
    
    string Animals::getColor(){
        return color;
    }

    void Animals::setWeight(double s)
    {
        weight = s;
    }
    double Animals::getWeight()
    {
        return weight;
    }
    void Animals::setDangerScore (int dS)
    {
        dangerScore = dS;
    }
    int Animals::getDangerScore()
    {
        return dangerScore;
    }
    void Animals::setName(string nameStr){
        name = nameStr;
    }
    string Animals::getName(){
        return name;
    }