#define TOOLS_H
#include <iostream>
using namespace std;

class Tools
{
    private:
    int powerLevel;
    string type;
    
    public:
    Tools();
    Tools(int pL, string t);
    void setPowerLevel(int pL);
    int getPowerLevel();
    void setType(string t);
    string getType();
};