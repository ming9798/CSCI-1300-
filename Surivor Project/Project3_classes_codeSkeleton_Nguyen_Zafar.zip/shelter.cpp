//CS1300
//Authors: Mia Nguyen and Tahira Zafar

#include "shelter.h"
#include <iostream>
#include <string>

using namespace std;


    Shelter::Shelter(){
        material = "";
        strength = 0;
    }
    Shelter::Shelter(string materialStr, int minigameScore){
        material = materialStr;
        strength = minigameScore;
    }
        
    string Shelter::getMaterial(){
        return material;
    }

    void Shelter::setMaterial(string materialStr){
        material = materialStr;
    }

    int Shelter::getStrength(){
        return strength;
    }

    void Shelter::setStrength(int minigameScore){
        strength = minigameScore;
    }
