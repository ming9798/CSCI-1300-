#include <iostream>

using namespace std;
int main() {
    cout <<"Hello world! Hello CSCi 1300" << endl;
}