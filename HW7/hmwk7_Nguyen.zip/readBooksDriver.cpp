#include <iostream>
#include "Book.h"
#include <fstream>
using namespace std;

int split(string str, char delimiter, string wordArray[], int arrSize) {
   string word = "";
   int j = 0;
   int numberOfWords = 0;
    for (int i = 0; i < str.length(); i++) {
        if (str[i] != delimiter) {
            word = word + str[i];
        }
        else if ( str[i] == delimiter && word.length() > 0) {
            wordArray[j] = word;
            j++;
            word = "";
            continue;
        }
        
        if( i == str.length()-1 && word.length() > 0){
            wordArray[j] = word;
            j++;
            word = "";
        }
    }
    if(j > arrSize) {
        return -1;
    } else {
        return j;
    }
}

int readBooks(string fileName, Book books[], int numBooksStored, int booksArrSize) {
    ifstream inFile;
    inFile.open(fileName);
    string line = "";

    if(numBooksStored >= booksArrSize) {
        return -2;
    }
    if (inFile.fail()){
        return -1;
    }
    char delimiter = ',';
    string wordArray[3] = {"","",""};
    int i = numBooksStored;

    while(getline(inFile, line)){
        string str = line;
        if(str.empty()){
            continue;
        }
        split(str,delimiter,wordArray,3);
        //cout << wordArray[0] << " " << wordArray[1] << " " << wordArray[2] << endl;
        Book book (wordArray[0],wordArray[1],wordArray[2]);
        books[i] = book;
        i++;
        numBooksStored++;

        if( numBooksStored >= booksArrSize) {
            return numBooksStored;
        }
        else {
            continue;
        }

    }

    //cout << "Book Array: " << endl;
    //for(int j = 0; j < totalBooks; j++){
       // cout << "Author: " << books[j].getAuthor() << "   Title: " << books[j].getTitle() << "   Genre: " << books[j].getGenre() << endl;
//}
    return numBooksStored;
}

int main() {
    string fileName = "file.txt";
    Book books[10];
    int numbooks = 3;
    int size = 3;
    readBooks(fileName, books, numbooks, size);
}