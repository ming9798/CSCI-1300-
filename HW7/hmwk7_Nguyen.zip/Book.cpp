#include "Book.h"
#include <iostream>
#include <string>

using namespace std; 


        Book::Book(){
            title = "";
            author = "";
            genre = "";
        }

        Book::Book(string titleStr, string authorStr, string genreStr){
            title = titleStr;
            author = authorStr;
            genre = genreStr;
        }

        string Book::getTitle(){
            return title;
        }

        void Book::setTitle(string titleStr){
            title = titleStr;
        }

        string Book::getAuthor(){
            return author;
        }

        void Book::setAuthor(string authorStr){
            author = authorStr;
        }

        string Book::getGenre(){
            return genre;
        }
        
        void Book::setGenre(string genreStr){
            genre = genreStr;
        }