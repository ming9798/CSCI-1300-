#include "Planet.h"
#include <iostream>
#include <cmath>
using namespace  std;

    
Planet::Planet(){
     planetName = "";
     planetRadius = 0.0;
} 

Planet::Planet(string name, double radius){
    planetName = name;
    planetRadius = radius;
} 

string Planet::getName(){
    return planetName;
}

void Planet::setName(string name){
    planetName = name;
}

double Planet::getRadius(){
    return planetRadius;
}

void Planet::setRadius(double radius){
    planetRadius = radius;
    
}

double Planet::getVolume(){
    double volume = (4/3.0) * M_PI * pow(planetRadius,3);
    return volume;
    
}