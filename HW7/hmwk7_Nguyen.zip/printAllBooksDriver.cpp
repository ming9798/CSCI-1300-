#include <iostream>
#include "Book.h"
#include <fstream>
using namespace std;

   void printAllBooks(Book books[], int numBooks){
    if(numBooks <= 0) {
        cout << "No books are stored" << endl;
    }
    else{
        cout << "Here is a list of books" << endl;
        for(int i = 0; i < numBooks; i++){
        cout << books[i].getTitle() << " by " << books[i].getAuthor() << endl;
        }
    }
}