#define PLANET_H
#include <iostream>

using namespace std;


class Planet{
    public:
    
        Planet(); //default constructor
        Planet(string name, double radius); //parameterized constructor

        string getName(); //accessor, returns planet name as string
        void setName(string name); //mutator, assigns planetName the value of the input string
        double getRadius(); //accesor, returns planetRadius as a double
        void setRadius(double radius); //mutator, assigns planetRadius the value of the input double
        double getVolume(); //accessor, calculates and returns the volume of the planet as a double

    private:
        string planetName;
        double planetRadius;
};