#include <iostream>
#include "Planet.h"
using namespace std;

int main() {
    string name = "AlienWorld";
    double radius = 18, newRadius = 499;
    Planet p1 = Planet(name, radius);
    cout << "Planet Name: " << p1.getName() << endl; 
    cout << "Planet Radius: " << p1.getRadius() << endl;
    cout << "Planet Volume: " << p1.getVolume() << endl;
    p1.setName("Awesome!!!");
    p1.setRadius(newRadius);
    cout << "Planet Name: " << p1.getName() << endl; 
    cout << "Planet Radius: " << p1.getRadius() << endl;
    cout << "Planet Volume: " << p1.getVolume() << endl;
}
