// CS1300 Fall 2020
// Author: Mia Nguyen
// Recitation: 511-Calista Nguyen
// Homework 2 - Problem #1 (Hello World)

#include <iostream>
using namespace std;

int main() {
    cout << "Hello, World!" << endl;
    return 0;
}