// CS1300 Fall 2020
// Author: Mia Nguyen
// Recitation: 511-Calista Nguyen
// Homework 2 - Problem #2 (Hello You)

#include <iostream>
using namespace std;

int main(){
    string firstName;
    cout << "Enter your name:\x0A";
    cin >> firstName;
    cout << "Hello, " << firstName << "!";
}
